Name: Pavani Guttula

Instructions to run the code:

Problem 1:
python preprocess.py dating-full.csv dating.csv

Problem 2:
python 2_1.py dating.csv
python 2_2.py dating.csv

Problem 3:
python discretize.py dating.csv dating-binned.csv

Problem 4:
python split.py dating-binned.csv trainingSet.csv testSet.csv

Problem 5:
python 5_1.py
python 5_2.py
python 5_3.py

Note:
* My code is in Python 2.7 format
* Applied laplace additive smooting to problem 5
